# Receipt Capture — Android App

A native Android app that captures receipt photos, crops them, extracts vendor/date/amount via OCR,
names the file as `YYYYMMDD-Vendor-Amount.jpg`, and lets you review and email it.

---

## Features

| Step | What happens |
|------|-------------|
| **Capture** | CameraX live preview with alignment guide overlay |
| **Crop** | UCrop — free-form or grid-guided cropping |
| **OCR** | Google ML Kit on-device text recognition |
| **Parse** | Regex + heuristics extract vendor, date, total amount |
| **Review** | All fields are editable before sending; filename preview updates live |
| **Send** | Android `ACTION_SEND` email intent with the receipt attached |

---

## Requirements

- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Min SDK 26 (Android 8.0 Oreo)
- A physical device is strongly recommended (camera + ML Kit OCR)

---

## Build Instructions

### 1. Open in Android Studio
```
File → Open → select the ReceiptCapture folder
```

### 2. Sync Gradle
Android Studio will automatically prompt to sync dependencies. Click **Sync Now**.

Key dependencies downloaded automatically:
- `androidx.camera:camera-*:1.3.1` (CameraX)
- `com.google.mlkit:text-recognition:16.0.0` (on-device OCR — no API key needed)
- `com.github.yalantis:ucrop:2.2.8` (image cropping UI)
- `androidx.appcompat`, `material`, `constraintlayout`, `lifecycle`

> **Note:** UCrop is hosted on JitPack. If the sync fails with a 404, add this to your
> root-level `build.gradle` repositories block:
> ```groovy
> maven { url 'https://jitpack.io' }
> ```

### 3. Run on Device
```
Run → Run 'app'  (Shift+F10)
```
Grant **Camera** permission when prompted.

---

## Project Structure

```
app/src/main/
├── java/com/receipts/capture/
│   ├── model/
│   │   └── ReceiptData.java          — Data model + filename builder
│   ├── utils/
│   │   ├── ReceiptParser.java        — OCR trigger + regex parsing
│   │   └── ImageUtils.java           — File/Bitmap helpers
│   ├── viewmodel/
│   │   └── ReceiptViewModel.java     — LiveData state holder
│   └── ui/
│       ├── MainActivity.java         — Entry point, permission check
│       ├── CameraActivity.java       — CameraX preview + shutter + UCrop launch
│       └── ReviewActivity.java       — OCR results, editable fields, email send
├── res/
│   ├── layout/
│   │   ├── activity_main.xml
│   │   ├── activity_camera.xml
│   │   └── activity_review.xml
│   ├── drawable/                     — Vector icons + shape drawables
│   ├── values/                       — Colors, strings, themes
│   └── xml/file_paths.xml            — FileProvider paths
└── AndroidManifest.xml
```

---

## Parsing Logic

### Vendor
Scans the first 5 text blocks from OCR output and picks the first "meaningful" line:
- Skips lines starting with digits (addresses, ZIP codes)
- Skips phone number patterns
- Skips lines containing "receipt", "www.", "tel:"

### Date
Tries these patterns in order:
1. `MM/DD/YYYY` or `MM-DD-YYYY`
2. `YYYY/MM/DD` or `YYYY-MM-DD`
3. `Month DD, YYYY` (e.g. "Jan 15, 2024")
4. `DD Month YYYY` (e.g. "15 January 2024")
5. `MM/DD/YY`

### Amount
1. Searches for lines containing "total", "amount due", "grand total", "balance due", "subtotal"
   and extracts the first dollar amount from that line.
2. Falls back to the **largest** numeric value matching `$?d{1,6}[.,]dd` on the page.

All extracted values are **editable** before sending — the filename preview updates live as you type.

---

## Filename Format

```
YYYYMMDD-VendorName-Amount.jpg
```
Examples:
```
20240315-Walmart-47.83.jpg
20241128-Cheesecake-123.50.jpg
00000000-Unknown-0.00.jpg    ← fallback when parsing fails
```

Special characters are stripped from vendor names; the `$` symbol is removed from amounts.

---

## Email

The app uses Android's standard `ACTION_SEND` intent, so it works with any email client the
user has installed (Gmail, Outlook, etc.). The receipt image is attached; the body includes
a plain-text summary of the extracted data.

---

## Customization

- **Default email address:** set `DEFAULT_EMAIL` constant in `ReviewActivity.java`
- **Improve OCR accuracy:** use `CAPTURE_MODE_MAXIMIZE_QUALITY` in `CameraActivity.java`
- **Add a custom font:** drop Inter `.ttf` files into `res/font/` and update `fontFamily` attrs

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| UCrop dependency not found | Add `maven { url 'https://jitpack.io' }` to root `build.gradle` |
| OCR returns empty fields | Ensure good lighting; edit fields manually |
| FileProvider crash | Check `applicationId` in `build.gradle` matches the authority in `AndroidManifest.xml` |
| Camera black screen on emulator | Use a physical device for camera testing |
