package com.receipts.capture.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.receipts.capture.model.ReceiptData;

public class ReceiptViewModel extends ViewModel {

    private final MutableLiveData<ReceiptData> receiptData = new MutableLiveData<>();
    private final MutableLiveData<String> croppedImagePath = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isProcessing = new MutableLiveData<>(false);

    public LiveData<ReceiptData> getReceiptData() { return receiptData; }
    public LiveData<String> getCroppedImagePath() { return croppedImagePath; }
    public LiveData<Boolean> getIsProcessing() { return isProcessing; }

    public void setReceiptData(ReceiptData data) { receiptData.setValue(data); }
    public void setCroppedImagePath(String path) { croppedImagePath.setValue(path); }
    public void setProcessing(boolean processing) { isProcessing.setValue(processing); }
}
