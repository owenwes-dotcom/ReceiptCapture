package com.receipts.capture.utils;

import android.graphics.Bitmap;
import android.util.Log;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.receipts.capture.model.ReceiptData;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReceiptParser {

    private static final String TAG = "ReceiptParser";

    public interface ParseCallback {
        void onSuccess(ReceiptData data);
        void onFailure(String error);
    }

    public static void parseReceipt(Bitmap bitmap, ParseCallback callback) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        InputImage image = InputImage.fromBitmap(bitmap, 0);

        recognizer.process(image)
            .addOnSuccessListener(visionText -> {
                ReceiptData data = extractReceiptInfo(visionText);
                callback.onSuccess(data);
            })
            .addOnFailureListener(e -> {
                Log.e(TAG, "OCR failed: " + e.getMessage());
                callback.onFailure(e.getMessage());
            });
    }

    private static ReceiptData extractReceiptInfo(Text visionText) {
        String fullText = visionText.getText();
        Log.d(TAG, "Full OCR text:\n" + fullText);

        ReceiptData data = new ReceiptData();
        data.setVendor(extractVendor(visionText));
        data.setDate(extractDate(fullText));
        data.setAmount(extractAmount(fullText));
        data.setFormattedDate(formatDateForFilename(data.getDate()));
        data.setCleanAmount(cleanAmountForFilename(data.getAmount()));
        return data;
    }

    // ── Vendor ─────────────────────────────────────────────────────────────────
    private static String extractVendor(Text visionText) {
        // Heuristic: vendor name is usually in the first 1-3 text blocks,
        // often the largest / first prominent line.
        List<Text.TextBlock> blocks = visionText.getTextBlocks();
        if (blocks.isEmpty()) return "Unknown";

        // Collect first few lines, skip very short ones or purely numeric lines
        for (int i = 0; i < Math.min(5, blocks.size()); i++) {
            for (Text.Line line : blocks.get(i).getLines()) {
                String text = line.getText().trim();
                // Skip lines that look like addresses, phone numbers, or are too short
                if (text.length() > 3
                        && !text.matches(".*\\d{3}[-.]\\d{3}[-.]\\d{4}.*")  // phone
                        && !text.matches("^\\d+.*")                          // starts with digits
                        && !text.toLowerCase().contains("receipt")
                        && !text.toLowerCase().contains("www.")
                        && !text.toLowerCase().contains("tel:")) {
                    return titleCase(text);
                }
            }
        }

        // Fallback: first line of first block
        if (!blocks.get(0).getLines().isEmpty()) {
            return titleCase(blocks.get(0).getLines().get(0).getText().trim());
        }
        return "Unknown";
    }

    // ── Date ───────────────────────────────────────────────────────────────────
    private static String extractDate(String text) {
        // Patterns ordered by specificity
        String[][] patterns = {
            // MM/DD/YYYY or MM-DD-YYYY
            {"(\\d{1,2}[/\\-]\\d{1,2}[/\\-]\\d{4})", "M/d/yyyy"},
            // YYYY/MM/DD or YYYY-MM-DD
            {"(\\d{4}[/\\-]\\d{1,2}[/\\-]\\d{1,2})", "yyyy/MM/dd"},
            // Month DD, YYYY  (e.g. "Jan 15, 2024")
            {"([A-Za-z]{3,9}\\s+\\d{1,2},?\\s+\\d{4})", "MMM dd yyyy"},
            // DD Month YYYY  (e.g. "15 January 2024")
            {"(\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{4})", "dd MMM yyyy"},
            // MM/DD/YY
            {"(\\d{1,2}[/\\-]\\d{1,2}[/\\-]\\d{2})", "M/d/yy"},
        };

        for (String[] entry : patterns) {
            Pattern p = Pattern.compile(entry[0]);
            Matcher m = p.matcher(text);
            if (m.find()) {
                String found = m.group(1).trim();
                Log.d(TAG, "Date candidate: " + found);
                return found;
            }
        }
        return "";
    }

    // ── Amount ─────────────────────────────────────────────────────────────────
    private static String extractAmount(String text) {
        // Look for "total", "amount due", "grand total" labels first
        String[] lines = text.split("\n");
        Pattern amountPattern = Pattern.compile("\\$?\\d{1,6}[.,]\\d{2}");

        // Priority: lines containing total keywords
        String[] keywords = {"total", "amount due", "grand total", "balance due", "subtotal"};
        List<String> candidates = new ArrayList<>();

        for (String line : lines) {
            String lower = line.toLowerCase();
            Matcher m = amountPattern.matcher(line);
            boolean hasAmount = m.find();
            if (!hasAmount) continue;
            String found = m.group();

            // Prefer "total" lines
            for (String kw : keywords) {
                if (lower.contains(kw)) {
                    return found; // immediate return on strong match
                }
            }
            candidates.add(found);
        }

        // Return the largest numeric value found as fallback (likely the total)
        if (!candidates.isEmpty()) {
            return candidates.stream()
                .max((a, b) -> {
                    double va = parseDouble(a);
                    double vb = parseDouble(b);
                    return Double.compare(va, vb);
                })
                .orElse(candidates.get(0));
        }
        return "";
    }

    // ── Helpers ────────────────────────────────────────────────────────────────
    public static String formatDateForFilename(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) return "00000000";

        // Normalize separators
        String normalized = dateStr.replaceAll("[,]", "").trim();

        String[][] formats = {
            {"M/d/yyyy"}, {"MM/dd/yyyy"}, {"M-d-yyyy"}, {"MM-dd-yyyy"},
            {"yyyy/MM/dd"}, {"yyyy-MM-dd"},
            {"MMM dd yyyy"}, {"MMMM dd yyyy"}, {"MMM d yyyy"}, {"MMMM d yyyy"},
            {"dd MMM yyyy"}, {"dd MMMM yyyy"},
            {"M/d/yy"}, {"MM/dd/yy"}
        };

        SimpleDateFormat out = new SimpleDateFormat("yyyyMMdd", Locale.US);
        for (String[] fmt : formats) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(fmt[0], Locale.US);
                sdf.setLenient(false);
                Date d = sdf.parse(normalized);
                if (d != null) return out.format(d);
            } catch (ParseException ignored) {}
        }
        // Try lenient parse
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy", Locale.US);
            Date d = sdf.parse(normalized);
            if (d != null) return out.format(d);
        } catch (ParseException ignored) {}

        return "00000000";
    }

    public static String cleanAmountForFilename(String amount) {
        if (amount == null || amount.isEmpty()) return "0.00";
        // Remove $ and spaces, keep digits, dot, comma
        return amount.replaceAll("[^\\d.,]", "").replace(",", ".");
    }

    private static double parseDouble(String s) {
        try {
            return Double.parseDouble(s.replace("$", "").replace(",", ""));
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private static String titleCase(String input) {
        if (input == null || input.isEmpty()) return input;
        String[] words = input.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                sb.append(Character.toUpperCase(word.charAt(0)));
                sb.append(word.substring(1).toLowerCase());
                sb.append(" ");
            }
        }
        return sb.toString().trim();
    }
}
