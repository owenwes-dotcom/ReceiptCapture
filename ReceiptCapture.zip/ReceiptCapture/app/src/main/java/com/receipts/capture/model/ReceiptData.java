package com.receipts.capture.model;

public class ReceiptData {
    private String vendor;
    private String date;       // raw extracted text
    private String amount;     // raw extracted text
    private String imagePath;
    private String formattedDate; // YYYYMMDD for filename
    private String cleanAmount;   // cleaned for filename (no $ or special chars)

    public ReceiptData() {}

    public ReceiptData(String vendor, String date, String amount, String imagePath) {
        this.vendor = vendor;
        this.date = date;
        this.amount = amount;
        this.imagePath = imagePath;
    }

    // Getters / Setters
    public String getVendor() { return vendor; }
    public void setVendor(String vendor) { this.vendor = vendor; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getAmount() { return amount; }
    public void setAmount(String amount) { this.amount = amount; }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    public String getFormattedDate() { return formattedDate; }
    public void setFormattedDate(String formattedDate) { this.formattedDate = formattedDate; }

    public String getCleanAmount() { return cleanAmount; }
    public void setCleanAmount(String cleanAmount) { this.cleanAmount = cleanAmount; }

    /**
     * Builds the filename: YYYYMMDD-Vendor-Amount
     */
    public String buildFileName() {
        String d = (formattedDate != null && !formattedDate.isEmpty()) ? formattedDate : "00000000";
        String v = (vendor != null && !vendor.isEmpty()) ? vendor.replaceAll("[^a-zA-Z0-9]", "") : "Unknown";
        String a = (cleanAmount != null && !cleanAmount.isEmpty()) ? cleanAmount : "0.00";
        return d + "-" + v + "-" + a + ".jpg";
    }
}
