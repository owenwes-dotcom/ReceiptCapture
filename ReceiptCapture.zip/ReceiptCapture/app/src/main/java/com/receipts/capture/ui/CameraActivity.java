package com.receipts.capture.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.receipts.capture.databinding.ActivityCameraBinding;
import com.receipts.capture.utils.ImageUtils;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

public class CameraActivity extends AppCompatActivity {

    private static final String TAG = "CameraActivity";

    private ActivityCameraBinding binding;
    private ImageCapture imageCapture;
    private File photoFile;

    private final ActivityResultLauncher<Intent> cropLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), this::handleCropResult);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCameraBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnShutter.setOnClickListener(v -> takePhoto());
        binding.btnBack.setOnClickListener(v -> finish());

        startCamera();
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> providerFuture =
            ProcessCameraProvider.getInstance(this);

        providerFuture.addListener(() -> {
            try {
                ProcessCameraProvider provider = providerFuture.get();
                bindCameraUseCases(provider);
            } catch (ExecutionException | InterruptedException e) {
                Log.e(TAG, "Camera init failed", e);
                Toast.makeText(this, "Camera failed to start.", Toast.LENGTH_LONG).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindCameraUseCases(ProcessCameraProvider provider) {
        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(binding.previewView.getSurfaceProvider());

        imageCapture = new ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build();

        // Rotate to match device orientation
        OrientationEventListener orientationListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int orientation) {
                if (imageCapture == null) return;
                int rotation;
                if (orientation >= 45 && orientation < 135) rotation = Surface.ROTATION_270;
                else if (orientation >= 135 && orientation < 225) rotation = Surface.ROTATION_180;
                else if (orientation >= 225 && orientation < 315) rotation = Surface.ROTATION_90;
                else rotation = Surface.ROTATION_0;
                imageCapture.setTargetRotation(rotation);
            }
        };
        orientationListener.enable();

        CameraSelector selector = CameraSelector.DEFAULT_BACK_CAMERA;
        provider.unbindAll();
        Camera camera = provider.bindToLifecycle(this, selector, preview, imageCapture);

        // Tap-to-focus
        binding.previewView.setOnTouchListener((v, event) -> {
            // simple pass-through; full tap-to-focus would require MeteringPoint
            return false;
        });
    }

    private void takePhoto() {
        if (imageCapture == null) return;
        binding.btnShutter.setEnabled(false);

        try {
            photoFile = ImageUtils.createTempImageFile(this);
        } catch (IOException e) {
            Toast.makeText(this, "Cannot create image file.", Toast.LENGTH_SHORT).show();
            binding.btnShutter.setEnabled(true);
            return;
        }

        ImageCapture.OutputFileOptions outputOptions =
            new ImageCapture.OutputFileOptions.Builder(photoFile).build();

        imageCapture.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
            new ImageCapture.OnImageSavedCallback() {
                @Override
                public void onImageSaved(@NonNull ImageCapture.OutputFileResults results) {
                    launchCrop(Uri.fromFile(photoFile));
                }

                @Override
                public void onError(@NonNull ImageCaptureException exception) {
                    Log.e(TAG, "Photo capture failed", exception);
                    Toast.makeText(CameraActivity.this, "Capture failed: " + exception.getMessage(),
                        Toast.LENGTH_SHORT).show();
                    binding.btnShutter.setEnabled(true);
                }
            });
    }

    private void launchCrop(Uri sourceUri) {
        try {
            File destFile = ImageUtils.createTempImageFile(this);
            Uri destUri = Uri.fromFile(destFile);

            UCrop.Options options = new UCrop.Options();
            options.setToolbarTitle("Crop Receipt");
            options.setFreeStyleCropEnabled(true);
            options.setShowCropGrid(true);
            options.setShowCropFrame(true);
            options.setHideBottomControls(false);
            options.setCompressionQuality(95);

            Intent cropIntent = UCrop.of(sourceUri, destUri)
                .withOptions(options)
                .getIntent(this);

            cropLauncher.launch(cropIntent);
        } catch (IOException e) {
            Log.e(TAG, "Crop setup failed", e);
            Toast.makeText(this, "Could not launch crop tool.", Toast.LENGTH_SHORT).show();
            binding.btnShutter.setEnabled(true);
        }
    }

    private void handleCropResult(ActivityResult result) {
        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
            Uri croppedUri = UCrop.getOutput(result.getData());
            if (croppedUri != null) {
                Intent reviewIntent = new Intent(this, ReviewActivity.class);
                reviewIntent.putExtra(ReviewActivity.EXTRA_CROPPED_PATH, croppedUri.getPath());
                startActivity(reviewIntent);
                finish();
            }
        } else if (result.getResultCode() == UCrop.RESULT_ERROR && result.getData() != null) {
            Throwable error = UCrop.getError(result.getData());
            Log.e(TAG, "Crop error", error);
            Toast.makeText(this, "Crop failed.", Toast.LENGTH_SHORT).show();
            binding.btnShutter.setEnabled(true);
        } else {
            // User cancelled crop — re-enable shutter
            binding.btnShutter.setEnabled(true);
        }
    }
}
