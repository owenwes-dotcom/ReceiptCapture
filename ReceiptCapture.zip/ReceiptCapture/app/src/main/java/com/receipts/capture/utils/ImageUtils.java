package com.receipts.capture.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ImageUtils {

    public static File createTempImageFile(Context context) throws IOException {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String fileName = "RECEIPT_" + timestamp + "_";
        File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(fileName, ".jpg", storageDir);
    }

    public static Uri getUriForFile(Context context, File file) {
        return FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);
    }

    public static File saveReceiptWithName(Context context, String sourcePath, String fileName) throws IOException {
        File dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (dir != null && !dir.exists()) dir.mkdirs();
        File dest = new File(dir, fileName);
        Bitmap bm = BitmapFactory.decodeFile(sourcePath);
        if (bm == null) throw new IOException("Could not decode image: " + sourcePath);
        try (FileOutputStream fos = new FileOutputStream(dest)) {
            bm.compress(Bitmap.CompressFormat.JPEG, 90, fos);
        }
        bm.recycle();
        return dest;
    }

    public static Bitmap loadBitmapFromUri(Context context, Uri uri) throws IOException {
        try (InputStream is = context.getContentResolver().openInputStream(uri)) {
            if (is == null) throw new IOException("Cannot open URI: " + uri);
            return BitmapFactory.decodeStream(is);
        }
    }

    public static Bitmap loadScaledBitmap(String path, int maxDim) {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, opts);
        int sample = 1;
        while (opts.outWidth / sample > maxDim || opts.outHeight / sample > maxDim) sample *= 2;
        opts.inJustDecodeBounds = false;
        opts.inSampleSize = sample;
        return BitmapFactory.decodeFile(path, opts);
    }
}
