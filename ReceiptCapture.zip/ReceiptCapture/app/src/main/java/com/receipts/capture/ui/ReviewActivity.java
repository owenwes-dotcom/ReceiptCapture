package com.receipts.capture.ui;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.receipts.capture.databinding.ActivityReviewBinding;
import com.receipts.capture.model.ReceiptData;
import com.receipts.capture.utils.ImageUtils;
import com.receipts.capture.utils.ReceiptParser;

import java.io.File;
import java.io.IOException;

public class ReviewActivity extends AppCompatActivity {

    public static final String EXTRA_CROPPED_PATH = "cropped_image_path";
    private static final String DEFAULT_EMAIL = ""; // user will fill in

    private ActivityReviewBinding binding;
    private ReceiptData receiptData;
    private String croppedPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityReviewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        croppedPath = getIntent().getStringExtra(EXTRA_CROPPED_PATH);
        if (croppedPath == null) {
            Toast.makeText(this, "No image to process.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Show image
        Bitmap bm = ImageUtils.loadScaledBitmap(croppedPath, 1200);
        if (bm != null) binding.imgReceipt.setImageBitmap(bm);

        showProcessing(true);
        runOcr();

        binding.btnSubmit.setOnClickListener(v -> submitReceipt());
        binding.btnRetake.setOnClickListener(v -> finish());

        // Live filename preview as user edits fields
        TextWatcher filenameWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) { updateFilenamePreview(); }
        };
        binding.etVendor.addTextChangedListener(filenameWatcher);
        binding.etDate.addTextChangedListener(filenameWatcher);
        binding.etAmount.addTextChangedListener(filenameWatcher);
    }

    private void runOcr() {
        Bitmap bm = ImageUtils.loadScaledBitmap(croppedPath, 1600);
        if (bm == null) {
            showProcessing(false);
            showOcrError("Could not load image for processing.");
            return;
        }

        ReceiptParser.parseReceipt(bm, new ReceiptParser.ParseCallback() {
            @Override
            public void onSuccess(ReceiptData data) {
                runOnUiThread(() -> {
                    receiptData = data;
                    receiptData.setImagePath(croppedPath);
                    populateFields(data);
                    showProcessing(false);
                });
            }

            @Override
            public void onFailure(String error) {
                runOnUiThread(() -> {
                    showProcessing(false);
                    showOcrError("OCR failed: " + error);
                    receiptData = new ReceiptData("Unknown", "", "", croppedPath);
                    populateFields(receiptData);
                });
            }
        });
    }

    private void populateFields(ReceiptData data) {
        binding.etVendor.setText(data.getVendor() != null ? data.getVendor() : "");
        binding.etDate.setText(data.getDate() != null ? data.getDate() : "");
        binding.etAmount.setText(data.getAmount() != null ? data.getAmount() : "");
        updateFilenamePreview();
    }

    private void updateFilenamePreview() {
        if (receiptData == null) return;

        String vendor = binding.etVendor.getText().toString().trim();
        String dateRaw = binding.etDate.getText().toString().trim();
        String amount = binding.etAmount.getText().toString().trim();

        receiptData.setVendor(vendor);
        receiptData.setDate(dateRaw);
        receiptData.setAmount(amount);
        receiptData.setFormattedDate(ReceiptParser.formatDateForFilename(dateRaw));
        receiptData.setCleanAmount(ReceiptParser.cleanAmountForFilename(amount));

        binding.tvFilename.setText(receiptData.buildFileName());
    }

    private void submitReceipt() {
        if (receiptData == null) return;

        String emailTo = binding.etEmail.getText().toString().trim();
        if (emailTo.isEmpty()) {
            binding.etEmail.setError("Enter a recipient email address.");
            binding.etEmail.requestFocus();
            return;
        }

        updateFilenamePreview(); // sync latest edits

        String fileName = receiptData.buildFileName();

        // Save the renamed file
        File savedFile;
        try {
            savedFile = ImageUtils.saveReceiptWithName(this, croppedPath, fileName);
        } catch (IOException e) {
            Toast.makeText(this, "Failed to save receipt image.", Toast.LENGTH_SHORT).show();
            return;
        }

        Uri fileUri = FileProvider.getUriForFile(
            this, getPackageName() + ".fileprovider", savedFile);

        // Build email intent with attachment
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("message/rfc822");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{emailTo});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Receipt: " + fileName.replace(".jpg", ""));
        emailIntent.putExtra(Intent.EXTRA_TEXT,
            "Please find the attached receipt.\n\n"
            + "Vendor: " + receiptData.getVendor() + "\n"
            + "Date:   " + receiptData.getDate() + "\n"
            + "Amount: " + receiptData.getAmount() + "\n\n"
            + "File: " + fileName);
        emailIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
        emailIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivity(Intent.createChooser(emailIntent, "Send receipt via…"));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "No email app installed.", Toast.LENGTH_LONG).show();
        }
    }

    private void showProcessing(boolean processing) {
        binding.progressBar.setVisibility(processing ? View.VISIBLE : View.GONE);
        binding.tvProcessing.setVisibility(processing ? View.VISIBLE : View.GONE);
        binding.cardFields.setVisibility(processing ? View.GONE : View.VISIBLE);
        binding.btnSubmit.setEnabled(!processing);
    }

    private void showOcrError(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
