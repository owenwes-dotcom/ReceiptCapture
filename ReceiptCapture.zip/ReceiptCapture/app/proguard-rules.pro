# Add project specific ProGuard rules here.
-keep class com.receipts.capture.model.** { *; }
-keep class com.google.mlkit.** { *; }
-keep class com.yalantis.ucrop.** { *; }
